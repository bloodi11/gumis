#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Conwerter.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("GuParser");
   // setupDemo(0);
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_pushButton_clicked()
{
    Conwerter con;
    vector<string> result;
    QVector<double> x(300), y(300);
    QString XMAX=ui->lineEdit->text();
    string exp=XMAX.toStdString();
    result = con.ONP(exp);

    for (int i=0; i<101; ++i)
    {
      x[i] = con.Parser(result, 1, 2)*i;
      y[i] = x[i]*i;
    }

    ui->customPlot->addGraph();
    ui->customPlot->graph(0)->setData(x, y);

    ui->customPlot->xAxis->setLabel("x");
    ui->customPlot->yAxis->setLabel("y");

    ui->customPlot->xAxis->setRange(-100, 100);
    ui->customPlot->yAxis->setRange(-100, 100);

    ui->customPlot->replot();

}
